import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

import '../models/cafe_model.dart';

class CafeService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final CollectionReference _cafesCollection = 
      FirebaseFirestore.instance.collection('cafes');

  // Get all cafes
  Stream<List<Cafe>> getCafes() {
    return _cafesCollection
        .orderBy('name')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Cafe.fromFirestore(doc))
            .toList());
  }

  // Get cafes near a location
  Stream<List<Cafe>> getNearbyContent(double latitude, double longitude, {double radiusKm = 10}) {
    // For a more sophisticated geo-query, you'd use GeoFlutterFire
    // For now, we'll get all cafes and filter client-side
    return _cafesCollection
        .snapshots()
        .map((snapshot) {
          final cafes = snapshot.docs
              .map((doc) => Cafe.fromFirestore(doc))
              .toList();
          
          // Filter by distance
          return cafes.where((cafe) {
            final distance = Geolocator.distanceBetween(
              latitude, longitude, cafe.latitude, cafe.longitude) / 1000;
            return distance <= radiusKm;
          }).toList()
            ..sort((a, b) {
              final distanceA = Geolocator.distanceBetween(
                latitude, longitude, a.latitude, a.longitude);
              final distanceB = Geolocator.distanceBetween(
                latitude, longitude, b.latitude, b.longitude);
              return distanceA.compareTo(distanceB);
            });
        });
  }

  // Get partner cafes
  Stream<List<Cafe>> getPartnerCafes() {
    return _cafesCollection
        .where('isPartner', isEqualTo: true)
        .orderBy('name')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Cafe.fromFirestore(doc))
            .toList());
  }

  // Get cafe by ID
  Future<Cafe?> getCafeById(String cafeId) async {
    try {
      final doc = await _cafesCollection.doc(cafeId).get();
      if (doc.exists) {
        return Cafe.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to fetch cafe: $e');
    }
  }

  // Search cafes by name or location
  Stream<List<Cafe>> searchCafes(String query) {
    return _cafesCollection
        .snapshots()
        .map((snapshot) {
          final cafes = snapshot.docs
              .map((doc) => Cafe.fromFirestore(doc))
              .toList();
          
          final lowercaseQuery = query.toLowerCase();
          return cafes.where((cafe) =>
              cafe.name.toLowerCase().contains(lowercaseQuery) ||
              cafe.address.toLowerCase().contains(lowercaseQuery) ||
              cafe.description.toLowerCase().contains(lowercaseQuery)
          ).toList();
        });
  }

  // Get top rated cafes
  Stream<List<Cafe>> getTopRatedCafes({int limit = 10}) {
    return _cafesCollection
        .where('rating', isGreaterThan: 4.0)
        .orderBy('rating', descending: true)
        .orderBy('reviewCount', descending: true)
        .limit(limit)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Cafe.fromFirestore(doc))
            .toList());
  }

  // Add a new cafe (admin function)
  Future<String> addCafe(Cafe cafe) async {
    try {
      final docRef = await _cafesCollection.add(cafe.toFirestore());
      return docRef.id;
    } catch (e) {
      throw Exception('Failed to add cafe: $e');
    }
  }

  // Update cafe
  Future<void> updateCafe(String cafeId, Map<String, dynamic> updates) async {
    try {
      await _cafesCollection.doc(cafeId).update({
        ...updates,
        'updatedAt': Timestamp.now(),
      });
    } catch (e) {
      throw Exception('Failed to update cafe: $e');
    }
  }

  // Calculate distance between user and cafe
  double calculateDistanceKm(Position userPosition, Cafe cafe) {
    return Geolocator.distanceBetween(
      userPosition.latitude,
      userPosition.longitude,
      cafe.latitude,
      cafe.longitude,
    ) / 1000; // Convert to kilometers
  }

  // Get cafes with specific amenities
  Stream<List<Cafe>> getCafesWithAmenities(List<String> amenities) {
    return _cafesCollection
        .where('amenities', arrayContainsAny: amenities)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Cafe.fromFirestore(doc))
            .toList());
  }

  // Get cafes that are currently open
  Stream<List<Cafe>> getOpenCafes() {
    return _cafesCollection
        .snapshots()
        .map((snapshot) {
          final cafes = snapshot.docs
              .map((doc) => Cafe.fromFirestore(doc))
              .toList();
          
          return cafes.where((cafe) => cafe.isOpen).toList();
        });
  }
}