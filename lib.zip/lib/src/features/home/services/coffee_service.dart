
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/coffee_model.dart';
import '../../../utils/logger.dart';

class CoffeeService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CoffeeService() {
    Logger.info('CoffeeService initialized', name: 'CoffeeService');
  }

  Stream<List<Coffee>> getCoffees() {
    Logger.dataOperation('Starting to listen for coffee collection changes', name: 'CoffeeService');
    
    return _firestore.collection('coffees').snapshots().map((snapshot) {
      try {
        Logger.dataOperation('Received ${snapshot.docs.length} coffee documents from Firestore', 
                           name: 'CoffeeService');
        
        final coffees = snapshot.docs.map((doc) {
          try {
            return Coffee.fromMap(doc.data(), doc.id);
          } catch (e) {
            Logger.dataOperation('Error parsing coffee document ${doc.id}', 
                               name: 'CoffeeService', error: e);
            // Return a placeholder coffee instead of crashing
            return Coffee(
              id: doc.id,
              name: 'Parse Error',
              description: 'Could not load this coffee',
              detailedDescription: 'Error parsing coffee data',
              photoUrl: '',
              basePrice: 0.0,
              sizes: {},
              ingredients: [],
              category: 'Error',
              isAvailable: false,
            );
          }
        }).toList();
        
        final availableCoffees = coffees.where((coffee) => coffee.isAvailable).length;
        Logger.dataOperation('Successfully parsed ${coffees.length} coffees ($availableCoffees available)', 
                           name: 'CoffeeService');
        
        return coffees;
      } catch (e) {
        Logger.dataOperation('Error processing coffee snapshot', 
                           name: 'CoffeeService', error: e);
        return <Coffee>[];
      }
    }).handleError((error) {
      Logger.dataOperation('Error in coffee stream', 
                         name: 'CoffeeService', error: error);
    });
  }

  Future<Coffee?> getCoffeeById(String coffeeId) async {
    Logger.logMethodCall('CoffeeService', 'getCoffeeById',
                        parameters: {'coffeeId': coffeeId});

    try {
      Logger.dataOperation('Fetching coffee by ID: $coffeeId', name: 'CoffeeService');

      final doc = await Logger.timeOperation(
        'Fetch Coffee by ID',
        () => _firestore.collection('coffees').doc(coffeeId).get(),
        name: 'CoffeeService',
      );

      if (doc.exists && doc.data() != null) {
        final coffee = Coffee.fromMap(doc.data()!, doc.id);
        Logger.dataOperation('Successfully fetched coffee: ${coffee.name}', name: 'CoffeeService');
        return coffee;
      } else {
        Logger.warning('Coffee not found with ID: $coffeeId', name: 'CoffeeService');
        return null;
      }
    } catch (e) {
      Logger.dataOperation('Error fetching coffee by ID: $coffeeId',
                         name: 'CoffeeService', error: e);
      rethrow;
    }
  }

  Future<List<Coffee>> getRandomCoffees(int count) async {
    Logger.logMethodCall('CoffeeService', 'getRandomCoffees',
                        parameters: {'count': count});

    try {
      Logger.dataOperation('Fetching $count random coffees from Firebase', name: 'CoffeeService');

      // First, get all coffee IDs to randomly select from
      final snapshot = await Logger.timeOperation(
        'Fetch All Coffee IDs',
        () => _firestore.collection('coffees').get(),
        name: 'CoffeeService',
      );

      if (snapshot.docs.isEmpty) {
        Logger.warning('No coffees found in database', name: 'CoffeeService');
        return [];
      }

      final allIds = snapshot.docs.map((doc) => doc.id).toList();
      final random = <Coffee>[];
      final usedIds = <String>{};

      // Randomly select coffee IDs and fetch them
      while (random.length < count && usedIds.length < allIds.length) {
        final randomIndex = (allIds.length * (DateTime.now().millisecondsSinceEpoch % 1000) / 1000).floor();
        final selectedId = allIds[randomIndex % allIds.length];

        if (usedIds.contains(selectedId)) continue;
        usedIds.add(selectedId);

        final coffee = await getCoffeeById(selectedId);
        if (coffee != null && coffee.isAvailable) {
          random.add(coffee);
          Logger.dataOperation('Added random coffee: ${coffee.name}', name: 'CoffeeService');
        }
      }

      Logger.dataOperation('Successfully fetched ${random.length} random coffees', name: 'CoffeeService');
      return random;
    } catch (e) {
      Logger.dataOperation('Error fetching random coffees',
                         name: 'CoffeeService', error: e);
      rethrow;
    }
  }
}
 