import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../home/models/coffee_model.dart';
import '../../home/services/coffee_service.dart';
import '../../home/services/favorites_service.dart';
import '../../coffee/screens/coffee_detail_screen.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedCategory = 'Tümü';
  String _sortBy = 'Adına Göre';
  List<Coffee> _randomCoffees = [];
  
  final List<String> _categories = [
    'Tümü',
    'Espresso Bazlı Kahveler',
    'Soğuk Espresso Bazlı Kahveler',
    'Filtre Kahve',
    'Cold Brew',
    'Diğer Kahve Çeşitleri',
    'Mocktail\'lar',
    'İçecekler',
    'Çaylar',
    'Atıştırmalık & Tatlılar',
  ];
  
  final List<String> _sortOptions = [
    'Adına Göre',
    'Fiyata Göre (Düşük)',
    'Fiyata Göre (Yüksek)',
    'Favoriler',
    'En Çok Satanlar',
  ];

  @override
  void initState() {
    super.initState();
    _loadRandomCoffees();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadRandomCoffees() async {
    try {
      final randomCoffees = await CoffeeService().getRandomCoffees(4);
      if (mounted) {
        setState(() {
          _randomCoffees = randomCoffees;
        });
      }
    } catch (e) {
      // Fallback: continue without random coffees
      print('Failed to load random coffees: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildSearchAndFilter(),
        Expanded(
          child: StreamProvider<List<Coffee>>.value(
            value: CoffeeService().getCoffees(),
            initialData: const [],
            child: Consumer<List<Coffee>>(
              builder: (context, coffees, child) {
                final filteredCoffees = _filterAndSortCoffees(coffees);
                return _buildProductContent(filteredCoffees);
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProductContent(List<Coffee> coffees) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_randomCoffees.isNotEmpty) ...[
            _buildSectionHeader('Önerilen'),
            const SizedBox(height: 12),
            _buildRecommendedList(_randomCoffees),
            const SizedBox(height: 24),
          ],
          _buildSectionHeader('Tüm Ürünler'),
          const SizedBox(height: 12),
          _buildProductGrid(coffees),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2D1B0E),
            ),
          ),
          if (title == 'Önerilen')
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF2D1B0E).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: InkWell(
                onTap: () {
                  // Refresh random coffees from Firebase
                  _loadRandomCoffees();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('Yeni öneriler yükleniyor...'),
                      backgroundColor: const Color(0xFF2D1B0E),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  );
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.refresh_rounded,
                      color: Color(0xFF2D1B0E),
                      size: 16,
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'Yenile',
                      style: TextStyle(
                        color: Color(0xFF2D1B0E),
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildRecommendedList(List<Coffee> coffees) {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: coffees.length,
        itemBuilder: (context, index) {
          final coffee = coffees[index];
          return Container(
            width: 160,
            margin: const EdgeInsets.only(right: 12),
            child: _buildProductCard(coffee),
          );
        },
      ),
    );
  }

  List<Coffee> _getRandomCoffees(List<Coffee> allCoffees, int count) {
    if (allCoffees.isEmpty) return [];
    
    // For presentation, just take the first few coffees and shuffle them
    final shuffled = List<Coffee>.from(allCoffees);
    shuffled.shuffle();
    return shuffled.take(count).toList();
  }

  Widget _buildSearchAndFilter() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2D1B0E),
            const Color(0xFF3D2314),
            const Color(0xFF4A2C1A),
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Mağaza',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tüm kahve çeşitlerimizi keşfedin',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white.withValues(alpha: 0.8),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: (value) {
                        setState(() {
                          _searchQuery = value.toLowerCase();
                        });
                      },
                      decoration: InputDecoration(
                        hintText: 'Kahve ara...',
                        hintStyle: TextStyle(color: Colors.grey[500]),
                        prefixIcon: Container(
                          margin: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFF2D1B0E).withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.search_rounded,
                            color: Color(0xFF2D1B0E),
                          ),
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 16,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 60,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  _buildFilterChip(
                    _selectedCategory == 'Tümü' ? 'Kategori' : _selectedCategory,
                    Icons.category_rounded,
                    () => _showCategoryDialog(),
                  ),
                  const SizedBox(width: 12),
                  _buildFilterChip(
                    _sortBy == 'Adına Göre' ? 'Sırala' : _sortBy,
                    Icons.sort_rounded,
                    () => _showSortDialog(),
                  ),
                  const SizedBox(width: 12),
                  if (_searchQuery.isNotEmpty || _selectedCategory != 'Tümü')
                    _buildFilterChip(
                      'Temizle',
                      Icons.clear_rounded,
                      () => _clearFilters(),
                      isAction: true,
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, IconData icon, VoidCallback onTap, {bool isAction = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isAction
              ? Colors.white
              : Colors.white.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(16),
          border: isAction
              ? null
              : Border.all(
                  color: Colors.white.withValues(alpha: 0.3),
                  width: 1,
                ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isAction ? const Color(0xFF2D1B0E) : Colors.white,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isAction ? const Color(0xFF2D1B0E) : Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductGrid(List<Coffee> coffees) {
    if (coffees.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFF2D1B0E).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(
                  Icons.search_off_rounded,
                  size: 64,
                  color: const Color(0xFF2D1B0E).withValues(alpha: 0.6),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Aradığınız kriterlere uygun\nürün bulunamadı',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF2D1B0E).withValues(alpha: 0.2),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: _clearFilters,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2D1B0E),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'Filtreleri Temizle',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(20),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.75,
        crossAxisSpacing: 16,
        mainAxisSpacing: 20,
      ),
      itemCount: coffees.length,
      itemBuilder: (context, index) {
        final coffee = coffees[index];
        return _buildProductCard(coffee);
      },
    );
  }

  Widget _buildProductCard(Coffee coffee) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CoffeeDetailScreen(coffee: coffee),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(20),
                    ),
                    child: Hero(
                      tag: 'coffee_${coffee.id}',
                      child: Image.network(
                        coffee.photoUrl,
                        width: double.infinity,
                        height: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  const Color(0xFF2D1B0E).withValues(alpha: 0.1),
                                  const Color(0xFF2D1B0E).withValues(alpha: 0.2),
                                ],
                              ),
                            ),
                            child: const Icon(
                              Icons.coffee,
                              size: 50,
                              color: Color(0xFF2D1B0E),
                            ),
                          );
                        },
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return Container(
                            color: Colors.grey[100],
                            child: Center(
                              child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                        loadingProgress.expectedTotalBytes!
                                    : null,
                                strokeWidth: 2,
                                color: const Color(0xFF2D1B0E),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Consumer<FavoritesService>(
                      builder: (context, favoritesService, _) {
                        return StreamBuilder<bool>(
                          stream: favoritesService.isFavorite(coffee.id),
                          builder: (context, snapshot) {
                            final isFavorite = snapshot.data ?? false;
                            return Container(
                              width: 32,
                              height: 32,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: IconButton(
                                  icon: Icon(
                                    isFavorite ? Icons.favorite : Icons.favorite_border,
                                    color: isFavorite ? Colors.red : Colors.grey,
                                    size: 18,
                                  ),
                                  onPressed: () {
                                    if (isFavorite) {
                                      favoritesService.removeFromFavorites(coffee.id);
                                    } else {
                                      favoritesService.addToFavorites(coffee.id);
                                    }
                                  },
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(
                                    minWidth: 32,
                                    minHeight: 32,
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                  if (!coffee.isAvailable)
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.6),
                          borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(12),
                          ),
                        ),
                        child: const Center(
                          child: Text(
                            'Stokta Yok',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    coffee.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Color(0xFF2D1B0E),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    coffee.category,
                    style: TextStyle(
                      color: const Color(0xFF2D1B0E).withValues(alpha: 0.6),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    coffee.description,
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 13,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2D1B0E),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${coffee.basePrice.toStringAsFixed(0)} ₺',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      if (coffee.isAvailable)
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFF2D1B0E).withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.add_rounded,
                            size: 16,
                            color: Color(0xFF2D1B0E),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Coffee> _filterAndSortCoffees(List<Coffee> coffees) {
    List<Coffee> filtered = coffees;

    // Filter by search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((coffee) {
        return coffee.name.toLowerCase().contains(_searchQuery) ||
            coffee.description.toLowerCase().contains(_searchQuery) ||
            coffee.category.toLowerCase().contains(_searchQuery);
      }).toList();
    }

    // Filter by category
    if (_selectedCategory != 'Tümü') {
      filtered = filtered.where((coffee) {
        return coffee.category.toLowerCase().contains(_selectedCategory.toLowerCase());
      }).toList();
    }

    // Sort
    switch (_sortBy) {
      case 'Adına Göre':
        filtered.sort((a, b) => a.name.compareTo(b.name));
        break;
      case 'Fiyata Göre (Düşük)':
        filtered.sort((a, b) => a.basePrice.compareTo(b.basePrice));
        break;
      case 'Fiyata Göre (Yüksek)':
        filtered.sort((a, b) => b.basePrice.compareTo(a.basePrice));
        break;
      case 'Favoriler':
        // For now, just shuffle. In real app, you'd sort by favorite count
        filtered.shuffle();
        break;
      case 'En Çok Satanlar':
        // For now, just shuffle. In real app, you'd sort by sales count
        filtered.shuffle();
        break;
      default:
        // Default sorting by name
        filtered.sort((a, b) => a.name.compareTo(b.name));
        break;
    }

    return filtered;
  }

  void _showCategoryDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Kategori Seçin'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _categories.length,
              itemBuilder: (context, index) {
                final category = _categories[index];
                return RadioListTile<String>(
                  title: Text(category),
                  value: category,
                  groupValue: _selectedCategory,
                  onChanged: (String? value) {
                    setState(() {
                      _selectedCategory = value!;
                    });
                    Navigator.of(context).pop();
                  },
                  toggleable: true,
                );
              },
            ),
          ),
        );
      },
    );
  }

  void _showSortDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Sıralama'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _sortOptions.length,
              itemBuilder: (context, index) {
                final option = _sortOptions[index];
                return RadioListTile<String>(
                  title: Text(option),
                  value: option,
                  groupValue: _sortBy,
                  onChanged: (String? value) {
                    setState(() {
                      _sortBy = value!;
                    });
                    Navigator.of(context).pop();
                  },
                  toggleable: true,
                );
              },
            ),
          ),
        );
      },
    );
  }

  void _clearFilters() {
    setState(() {
      _searchController.clear();
      _searchQuery = '';
      _selectedCategory = 'Tümü';
      _sortBy = 'Adına Göre';
    });
  }
}